package com.csgp.cardatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
